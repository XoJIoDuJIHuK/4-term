import University.*;
public class Main {
    public static void main(String[] args) {
        university.Task(Student.GetStudents());
        //Road.Task(6);
    }
}